import { useLayoutEffect, useRef, useState } from "react";

import "./task-banner.css";

export const TaskBanner = () => {
  const divRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState("auto");

  useLayoutEffect(() => {
    const height = divRef.current?.getBoundingClientRect().height;
    setHeight("0px");
    const rafId = requestAnimationFrame(() => {
      setHeight(`${height}px`);
    });

    return () => {
      cancelAnimationFrame(rafId);
    };
  }, []);

  return (
    <div className="task-banner" ref={divRef} style={{ height: height }}>
      Lorem Ipsum is simply dummy text of the printing and typesetting industry.
      Lorem Ipsum has been the industry's standard dummy text ever since the
      1500s, when an unknown printer took a galley of type and scrambled it to
      make a type specimen book. It has survived not only five centuries, but
      also the leap into electronic typesetting, remaining essentially
      unchanged. It was popularised in the 1960s with the release of Letraset
      sheets containing Lorem Ipsum passages, and more recently with desktop
      publishing software like Aldus PageMaker including versions of Lorem
      Ipsum.
    </div>
  );
};
